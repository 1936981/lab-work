﻿namespace Lab_Work1
{
    partial class frmCombo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnshowselect = new System.Windows.Forms.Button();
            this.btnremovebyname = new System.Windows.Forms.Button();
            this.btnremovebynumber = new System.Windows.Forms.Button();
            this.btnremovelast = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.cmbdays = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // btnshowselect
            // 
            this.btnshowselect.Location = new System.Drawing.Point(88, 42);
            this.btnshowselect.Name = "btnshowselect";
            this.btnshowselect.Size = new System.Drawing.Size(130, 36);
            this.btnshowselect.TabIndex = 0;
            this.btnshowselect.Text = "Show select";
            this.btnshowselect.UseVisualStyleBackColor = true;
            this.btnshowselect.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnremovebyname
            // 
            this.btnremovebyname.Location = new System.Drawing.Point(264, 42);
            this.btnremovebyname.Name = "btnremovebyname";
            this.btnremovebyname.Size = new System.Drawing.Size(172, 36);
            this.btnremovebyname.TabIndex = 1;
            this.btnremovebyname.Text = "Remove by name";
            this.btnremovebyname.UseVisualStyleBackColor = true;
            this.btnremovebyname.Click += new System.EventHandler(this.btnremovebyname_Click);
            // 
            // btnremovebynumber
            // 
            this.btnremovebynumber.Location = new System.Drawing.Point(490, 42);
            this.btnremovebynumber.Name = "btnremovebynumber";
            this.btnremovebynumber.Size = new System.Drawing.Size(188, 36);
            this.btnremovebynumber.TabIndex = 2;
            this.btnremovebynumber.Text = "Remove by number ";
            this.btnremovebynumber.UseVisualStyleBackColor = true;
            this.btnremovebynumber.Click += new System.EventHandler(this.btnremovebynumber_Click);
            // 
            // btnremovelast
            // 
            this.btnremovelast.Location = new System.Drawing.Point(254, 162);
            this.btnremovelast.Name = "btnremovelast";
            this.btnremovelast.Size = new System.Drawing.Size(151, 62);
            this.btnremovelast.TabIndex = 3;
            this.btnremovelast.Text = "Remove last";
            this.btnremovelast.UseVisualStyleBackColor = true;
            this.btnremovelast.Click += new System.EventHandler(this.btnremovelast_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(402, 306);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(105, 36);
            this.btnBack.TabIndex = 4;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // cmbdays
            // 
            this.cmbdays.FormattingEnabled = true;
            this.cmbdays.Location = new System.Drawing.Point(71, 144);
            this.cmbdays.Name = "cmbdays";
            this.cmbdays.Size = new System.Drawing.Size(121, 28);
            this.cmbdays.TabIndex = 5;
            // 
            // frmCombo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cmbdays);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnremovelast);
            this.Controls.Add(this.btnremovebynumber);
            this.Controls.Add(this.btnremovebyname);
            this.Controls.Add(this.btnshowselect);
            this.Name = "frmCombo";
            this.Text = "Combo";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnshowselect;
        private System.Windows.Forms.Button btnremovebyname;
        private System.Windows.Forms.Button btnremovebynumber;
        private System.Windows.Forms.Button btnremovelast;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.ComboBox cmbdays;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Work1
{
    public partial class frmFood : Form
    {
        public frmFood()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void btnshow_Click(object sender, EventArgs e)
        {

            String msg = "";

            if (Coffee.Checked == true)
            {
                msg = Coffee.Text;
            }

            if (Dount.Checked == true)
            {
                msg = msg + " " + Dount.Text; ;
            }


            if (Brownie.Checked == true)
            {
                msg = msg + " " + Brownie.Text; ;
            }

            if (msg.Length > 0)
            {
                MessageBox.Show(msg + " selected");
            }
            else
                MessageBox.Show("Nothing selected");
        }
    }
}

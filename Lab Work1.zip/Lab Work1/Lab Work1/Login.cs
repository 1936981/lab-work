﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Work1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Login successful");
        }

        private void Radio_Click(object sender, EventArgs e)
        {
            frmRadio frm = new frmRadio();
            frm.ShowDialog();
        }

        private void Food_Click(object sender, EventArgs e)
        {
            frmFood frm = new frmFood();
            frm.ShowDialog();
        }

        private void Combo_Click(object sender, EventArgs e)
        {
            frmCombo frm = new frmCombo();
            frm.ShowDialog();
        }

        private void randomcolor2_Click(object sender, EventArgs e)
        {
            frmRandomColor frm = new frmRandomColor();
            frm.ShowDialog();
        }

        private void random_Click(object sender, EventArgs e)
        {
            frmRandomCombo frm = new frmRandomCombo();
            frm.ShowDialog();
        }

        private void Array_Click(object sender, EventArgs e)
        {
           
        }

        private void Array_Click_1(object sender, EventArgs e)
        {
            frmArray frm = new frmArray();
            frm.ShowDialog();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}

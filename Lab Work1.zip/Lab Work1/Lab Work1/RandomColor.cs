﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Work1
{
    public partial class frmRandomColor : Form
    {
        Random y = new Random();

        public frmRandomColor()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            int r = y.Next(0, 255);
            int g = y.Next(0, 255);
            int b = y.Next(0, 255);

            btnColor.BackColor = Color.FromArgb(r, g, b);
            rgb1.Text = Convert.ToString(r) + "-" + Convert.ToString(g) + "-" + Convert.ToString(b);
        }

        private void btnNumber_Click(object sender, EventArgs e)
        {
            btnNumber.Text = Convert.ToString(y.Next(1, 100));
        }

        private void rgb1_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace Lab_Work1
{
    partial class frmRandomColor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnColor = new System.Windows.Forms.Button();
            this.btnNumber = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.rgb1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnColor
            // 
            this.btnColor.Location = new System.Drawing.Point(218, 36);
            this.btnColor.Name = "btnColor";
            this.btnColor.Size = new System.Drawing.Size(358, 47);
            this.btnColor.TabIndex = 0;
            this.btnColor.Text = "Generate Random Color";
            this.btnColor.UseVisualStyleBackColor = true;
            this.btnColor.Click += new System.EventHandler(this.btnColor_Click);
            // 
            // btnNumber
            // 
            this.btnNumber.Location = new System.Drawing.Point(91, 232);
            this.btnNumber.Name = "btnNumber";
            this.btnNumber.Size = new System.Drawing.Size(163, 47);
            this.btnNumber.TabIndex = 1;
            this.btnNumber.Text = "Random Number";
            this.btnNumber.UseVisualStyleBackColor = true;
            this.btnNumber.Click += new System.EventHandler(this.btnNumber_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(553, 311);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(101, 41);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.button3_Click);
            // 
            // rgb1
            // 
            this.rgb1.AutoSize = true;
            this.rgb1.Location = new System.Drawing.Point(364, 102);
            this.rgb1.Name = "rgb1";
            this.rgb1.Size = new System.Drawing.Size(42, 20);
            this.rgb1.TabIndex = 3;
            this.rgb1.Text = "r-g-b";
            this.rgb1.Click += new System.EventHandler(this.rgb1_Click);
            // 
            // frmRandomColor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.rgb1);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnNumber);
            this.Controls.Add(this.btnColor);
            this.Name = "frmRandomColor";
            this.Text = "RandomColor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnColor;
        private System.Windows.Forms.Button btnNumber;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label rgb1;
    }
}
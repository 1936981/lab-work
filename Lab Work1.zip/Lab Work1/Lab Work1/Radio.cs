﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_Work1
{
    public partial class frmRadio : Form
    {
        public frmRadio()
        {
            InitializeComponent();
        }

        private void rdoRed_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked == true)
                rdoRed.ForeColor = Color.FromName("red");
            else
                rdoRed.ForeColor = Color.FromName("black");
        }

        private void rdoGreen_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoGreen.Checked == true)
                rdoGreen.ForeColor = Color.FromName("green");
            else
                rdoGreen.ForeColor = Color.FromName("black");
        }

        private void rdoBlue_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoBlue.Checked == true)
                rdoBlue.ForeColor = Color.FromName("blue");
            else
                rdoBlue.ForeColor = Color.FromName("black");
        }

        private void rdoYellow_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoYellow.Checked == true)
                rdoYellow.ForeColor = Color.FromName("Yellow");
            else
                rdoYellow.ForeColor = Color.FromName("black");
        }

        private void rdoRed2_CheckedChanged(object sender, EventArgs e)
        {
            rdoRed2.ForeColor = Color.FromName("red");
        }

        private void rdoGreen2_CheckedChanged(object sender, EventArgs e)
        {
            rdoGreen2.ForeColor = Color.FromName("green");
        }

        private void rdoBlue2_CheckedChanged(object sender, EventArgs e)
        {
            rdoBlue2.ForeColor = Color.FromName("blue");
        }

        private void rdoYellow2_CheckedChanged(object sender, EventArgs e)
        {
            rdoYellow2.ForeColor = Color.FromName("yellow");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            rdoRed.Checked = false;
            rdoGreen.Checked = false;
            rdoBlue.Checked = false;
            rdoYellow.Checked = false;

            rdoRed.ForeColor = Color.FromName("black");
            rdoGreen.ForeColor = Color.FromName("black");
            rdoBlue.ForeColor = Color.FromName("black");
            rdoYellow.ForeColor = Color.FromName("black");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
    }
}

﻿namespace Lab_Work1
{
    partial class frmFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnshow = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.Coffee = new System.Windows.Forms.CheckBox();
            this.Dount = new System.Windows.Forms.CheckBox();
            this.Brownie = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // btnshow
            // 
            this.btnshow.Location = new System.Drawing.Point(259, 48);
            this.btnshow.Name = "btnshow";
            this.btnshow.Size = new System.Drawing.Size(102, 42);
            this.btnshow.TabIndex = 0;
            this.btnshow.Text = "Show";
            this.btnshow.UseVisualStyleBackColor = true;
            this.btnshow.Click += new System.EventHandler(this.btnshow_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(349, 255);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(96, 33);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Coffee
            // 
            this.Coffee.AutoSize = true;
            this.Coffee.Location = new System.Drawing.Point(248, 115);
            this.Coffee.Name = "Coffee";
            this.Coffee.Size = new System.Drawing.Size(83, 24);
            this.Coffee.TabIndex = 2;
            this.Coffee.Text = "Coffee";
            this.Coffee.UseVisualStyleBackColor = true;
            // 
            // Dount
            // 
            this.Dount.AutoSize = true;
            this.Dount.Location = new System.Drawing.Point(248, 168);
            this.Dount.Name = "Dount";
            this.Dount.Size = new System.Drawing.Size(79, 24);
            this.Dount.TabIndex = 3;
            this.Dount.Text = "Dount";
            this.Dount.UseVisualStyleBackColor = true;
            // 
            // Brownie
            // 
            this.Brownie.AutoSize = true;
            this.Brownie.Location = new System.Drawing.Point(248, 214);
            this.Brownie.Name = "Brownie";
            this.Brownie.Size = new System.Drawing.Size(92, 24);
            this.Brownie.TabIndex = 4;
            this.Brownie.Text = "Brownie";
            this.Brownie.UseVisualStyleBackColor = true;
            // 
            // frmFood
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Brownie);
            this.Controls.Add(this.Dount);
            this.Controls.Add(this.Coffee);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnshow);
            this.Name = "frmFood";
            this.Text = "Food";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnshow;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.CheckBox Coffee;
        private System.Windows.Forms.CheckBox Dount;
        private System.Windows.Forms.CheckBox Brownie;
    }
}